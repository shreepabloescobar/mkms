## `registerFieldTemplate` is deprecated
    hmm it's true :(, we don't encourage this type of customization anymore, it ends up opening some security holes, we prefer the use of UIKit. If you feel any difficulty let us know
## `attachment.actions` is deprecated
    same reason above
## `attachment PDF preview` is no longer being rendered
    it is temporarily disabled, nowadays is huge effort render the previews and requires the download of the entire file on the client. We are working to improve this :)