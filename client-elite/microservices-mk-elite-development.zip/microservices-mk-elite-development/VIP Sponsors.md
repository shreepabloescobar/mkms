# Rocket.Chat VIP Sponsors

These are the people supporting Rocket.Chat. Thank you very much!!


- [Johannes Kinast](https://github.com/goaround)
- [sAuCE](https://github.com/lukejw)
