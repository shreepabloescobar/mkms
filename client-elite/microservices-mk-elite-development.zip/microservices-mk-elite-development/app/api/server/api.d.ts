import { APIClass } from '.';

export declare const API: {
	v1: APIClass;
	default: APIClass;
};
