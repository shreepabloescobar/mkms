# REST API Helpers

## What are they?
Helpers are functions which get injected into the context of `this` on each request the REST API recieves. This allows for commonly used code, such as retriving the target user, to be placed in one spot and used throughout the entire REST API code base.
