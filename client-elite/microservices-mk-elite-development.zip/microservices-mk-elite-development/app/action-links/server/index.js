import { actionLinks } from './lib/actionLinks';
import './actionLinkHandler';

export {
	actionLinks,
};
