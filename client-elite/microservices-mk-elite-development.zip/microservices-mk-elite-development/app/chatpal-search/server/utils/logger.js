import { Logger } from '../../../logger';

const ChatpalLogger = new Logger('Chatpal Logger');
export default ChatpalLogger;
