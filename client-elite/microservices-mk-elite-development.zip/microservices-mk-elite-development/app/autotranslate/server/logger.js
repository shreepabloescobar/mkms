import { Logger } from '../../logger/server';

const logger = new Logger('AutoTranslate');

export const msLogger = logger.section('Microsoft');
