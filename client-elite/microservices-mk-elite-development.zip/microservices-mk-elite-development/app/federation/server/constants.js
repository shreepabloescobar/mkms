export const STATUS_ENABLED = 'Enabled';
export const STATUS_REGISTERING = 'Registering with Hub...';
export const STATUS_ERROR_REGISTERING = 'Could not register with Hub';
export const STATUS_DISABLED = 'Disabled';
