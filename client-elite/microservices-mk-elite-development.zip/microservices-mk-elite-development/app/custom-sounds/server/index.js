import './startup/custom-sounds';
import './startup/permissions';
import './startup/settings';
import './methods/deleteCustomSound';
import './methods/insertOrUpdateSound';
import './methods/listCustomSounds';
import './methods/uploadCustomSound';
