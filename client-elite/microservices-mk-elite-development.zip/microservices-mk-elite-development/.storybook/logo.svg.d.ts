declare const path: string;
export = path;
